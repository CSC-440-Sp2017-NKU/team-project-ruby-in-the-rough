require 'test_helper'

class Course2userTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
