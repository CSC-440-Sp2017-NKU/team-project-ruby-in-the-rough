class Course2usersController < ApplicationController
    def new
        @course2user = Course2user.new
    end
    
    def edit
    end
    
    def create
        @course2user = Course2user.new(course2user_params)
        @course2user.user_id = get_regis_cr_user?
        
        respond_to do |format|
            if @course2user.save
                format.html { redirect_to registrar_path, notice: 'Course2user was successfully created.' }
                format.json { render :show, status: :created, location: @course2user }
            else
                format.html { render :new }
                format.json { render json: @course2user.errors, status: :unprocessable_entity }
            end
        end
    end
    
    def update
        respond_to do |format|
          if @course2user.update(course2user_params)
            format.html { redirect_to registrar_path, notice: 'Course2user was successfully updated.' }
            format.json { render :show, status: :ok, location: @course2user }
          else
            format.html { render :edit }
            format.json { render json: @course2user.errors, status: :unprocessable_entity }
          end
        end
    end
    
    def destroy
        @course2user.destroy
        respond_to do |format|
          format.html { redirect_to registrar_path, notice: 'Course2user was successfully destroyed.' }
          format.json { head :no_content }
        end
    end
    
    private
        # Use callbacks to share common setup or constraints between actions.
        def set_course2user
          @course2user = Course2user.find(params[:id])
        end
    
        # Never trust parameters from the scary internet, only allow the white list through.
        def course2user_params
          params.require(:course2user).permit(:course_id)
        end
end
