class AddFlagToQuestions < ActiveRecord::Migration[5.0]
  def change
    add_column :questions, :is_flagged, :integer
    add_column :questions, :rep, :integer
  end
end
