class CreateCourse2users < ActiveRecord::Migration[5.0]
  def change
    create_table :course2users do |t|

      t.timestamps
    end
  end
end
