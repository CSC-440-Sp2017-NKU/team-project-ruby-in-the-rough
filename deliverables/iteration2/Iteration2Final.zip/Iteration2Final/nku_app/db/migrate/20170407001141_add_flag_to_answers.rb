class AddFlagToAnswers < ActiveRecord::Migration[5.0]
  def change
    add_column :answers, :is_flagged, :integer
    add_column :answers, :rep, :integer
  end
end
