class ControlPanel < ApplicationRecord
    
end