module SessionsHelper
  def log_in(user)
    session[:user_id] = user.id
  end

  # Returns the current logged-in user (if any).
  def current_user
    @current_user ||= User.find_by(id: session[:user_id])
  end

  def get_user?
    return session[:user_id]
  end
  
  def get_user_name?
    return User.find_by(id: session[:user_id]).name
  end

  # Returns true if the user is logged in, false otherwise.
  def logged_in?
    !current_user.nil?
  end
  
  def shares_course_id(user2)
    current_user.courses.each do |id_1|
      user2.courses.each do |id_2|
        if(id_1 == id_2)
          return true
        end
      end
    end
    return false
  end
  
  def can_view_crs(c_id)
    if (get_UAL? == 4)
      return true
    end
    c2u = Course2user.find_by(course_id: c_id, user_id: session[:user_id])
    
    if (!c2u.nil?) 
      return true
    else
      return false
    end
  end
  
  def set_course(course_id)
    session[:cur_course] = course_id
  end   
  
  def get_course?
    return session[:cur_course]
  end
  
  def set_question(question_id)
    session[:cur_question] = question_id
  end   
  
  def get_question?
    return session[:cur_question]
  end
  
  def owns_question(q_id)
    if (Question.find_by(id: q_id).user_id == get_user?)
      return true
    else
      return false
    end
  end
  
  def owns_answer(a_id)
    if (Answer.find_by(id: a_id).user_id == get_user?)
      return true
    else
      return false
    end
  end
  
  def set_regis_cr_user(u_id)
    session[:regis_cr_user] = u_id
  end
  
  def get_regis_cr_user?
    return session[:regis_cr_user]
  end
  
  def get_UAL?
    return @current_user.accesslevel
  end
  
  def log_out
    session.delete(:user_id)
    @current_user = nil
  end
end