module UsersHelper
    #def add_course(course_id)
    #   course2users.add_course(course_id, @user.id)
    #end <-- I don't think this even did anything; pretty sure I wrote it and forgot to delete it
end
