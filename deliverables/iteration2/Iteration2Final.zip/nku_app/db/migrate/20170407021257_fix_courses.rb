class FixCourses < ActiveRecord::Migration[5.0]
  def change
    drop_table :courses
    
    create_table :courses do |t|
      t.integer :course_id
      t.string :name
      t.string :academic_label
      t.string :description
      t.string :question
    end
  end
end
