# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20170504010931) do

  create_table "answer_votes", force: :cascade do |t|
    t.integer "user_id"
    t.integer "answer_id"
    t.integer "value",     default: 0
    t.index ["answer_id"], name: "index_answer_votes_on_answer_id"
    t.index ["user_id"], name: "index_answer_votes_on_user_id"
  end

  create_table "answers", force: :cascade do |t|
    t.text     "content"
    t.integer  "rep",         default: 0
    t.integer  "is_flagged"
    t.integer  "user_id"
    t.integer  "question_id"
    t.datetime "time_stamp"
    t.index ["question_id"], name: "index_answers_on_question_id"
    t.index ["user_id"], name: "index_answers_on_user_id"
  end

  create_table "course2users", force: :cascade do |t|
    t.integer "course_id"
    t.integer "user_id"
    t.index ["course_id"], name: "index_course2users_on_course_id"
    t.index ["user_id"], name: "index_course2users_on_user_id"
  end

  create_table "courses", force: :cascade do |t|
    t.string "name"
    t.string "academic_label"
    t.string "description"
  end

  create_table "friends", force: :cascade do |t|
    t.integer "user_id"
    t.integer "user2_id"
    t.index ["user2_id"], name: "index_friends_on_user2_id"
    t.index ["user_id"], name: "index_friends_on_user_id"
  end

  create_table "messages", primary_key: "msg_id", force: :cascade do |t|
    t.integer  "from_user_id"
    t.integer  "to_user_id"
    t.string   "title"
    t.string   "content"
    t.datetime "send_date"
    t.integer  "is_read",      default: 0
    t.index ["from_user_id"], name: "index_messages_on_from_user_id"
    t.index ["to_user_id"], name: "index_messages_on_to_user_id"
  end

  create_table "question_votes", force: :cascade do |t|
    t.integer "user_id"
    t.integer "question_id"
    t.integer "value",       default: 0
    t.index ["question_id"], name: "index_question_votes_on_question_id"
    t.index ["user_id"], name: "index_question_votes_on_user_id"
  end

  create_table "questions", force: :cascade do |t|
    t.text     "title"
    t.text     "content"
    t.integer  "rep",        default: 0
    t.integer  "is_flagged"
    t.integer  "course_id"
    t.integer  "user_id"
    t.datetime "time_stamp"
    t.index ["course_id"], name: "index_questions_on_course_id"
    t.index ["user_id"], name: "index_questions_on_user_id"
  end

  create_table "users", force: :cascade do |t|
    t.string   "name"
    t.string   "email"
    t.integer  "rep",         default: 0
    t.integer  "accesslevel"
    t.datetime "time_stamp"
  end

end
