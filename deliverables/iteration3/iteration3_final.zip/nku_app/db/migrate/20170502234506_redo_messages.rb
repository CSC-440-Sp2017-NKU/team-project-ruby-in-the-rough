class RedoMessages < ActiveRecord::Migration[5.0]
  def change
    drop_table :messages
    
    create_table :messages, primary_key: 'msg_id' do |t|
      t.references :from_user
      t.references :to_user
      t.string :title
      t.string :content
      t.datetime :send_date
    end
  end
end
