class FixTables3 < ActiveRecord::Migration[5.0]
  def change
    drop_table :answers
    drop_table :questions, force: :cascade
    drop_table :courses2users, force: :cascade
    drop_table :courses, force: :cascade
    drop_table :users, force: :cascade
    
    create_table :courses do |t|
      t.string :name
      t.string :academic_label
      t.string :description
    end
    
    create_table :users do |t|
      t.string :name
      t.string :email
      t.integer :rep, :default => 0
      t.integer :acceslevel, :default => 1 #TODO: add default value
    end
    
    create_table :courses2users do |t| #<-- junction table
      t.references :courses, foreign_key: true
      t.references :users, foreign_key: true
    end
    
    create_table :questions do |t|
      t.text :title
      t.text :content
      t.integer :rep, :default => 0
      t.integer :is_flagged
      t.references :course, foreign_key: true
      t.references :user, foreign_key: true
    end
    
    create_table :answers do |t|
      t.text :content
      t.integer :rep, :default => 0
      t.integer :is_flagged
      t.references :user, foreign_key: true
      t.references :question, foreign_key: true
    end
  end
end
