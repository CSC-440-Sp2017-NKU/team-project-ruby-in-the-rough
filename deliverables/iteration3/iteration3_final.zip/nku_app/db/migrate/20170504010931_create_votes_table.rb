class CreateVotesTable < ActiveRecord::Migration[5.0]
  def change
    create_table :question_votes do |t|
      t.references :user
      t.references :question
      t.integer :value, default: 0
    end
    
    create_table :answer_votes do |t|
      t.references :user
      t.references :answer
      t.integer :value, default: 0
    end
  end
end
