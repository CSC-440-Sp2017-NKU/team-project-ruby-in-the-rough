class AddIsreadToMessages < ActiveRecord::Migration[5.0]
  def change
    add_column :messages, :is_read, :integer, :default => 0
  end
end
