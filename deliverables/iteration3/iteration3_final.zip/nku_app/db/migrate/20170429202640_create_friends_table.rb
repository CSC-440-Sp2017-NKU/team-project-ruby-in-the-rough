class CreateFriendsTable < ActiveRecord::Migration[5.0]
  def change
    create_table :friends do |t|
      t.references :user1
      t.references :user2
    end
  end
end
