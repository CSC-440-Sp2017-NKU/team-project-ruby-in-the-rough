class AddTypeToUsers < ActiveRecord::Migration[5.0]
  def change
    add_column :users, :type, :integer
    add_column :users, :rep, :integer
  end
end
