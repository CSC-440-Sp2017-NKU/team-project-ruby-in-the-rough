class AddTimeStampToQuestion < ActiveRecord::Migration[5.0]
  def change
    add_column :questions, :time_stamp, :datetime
  end
end
