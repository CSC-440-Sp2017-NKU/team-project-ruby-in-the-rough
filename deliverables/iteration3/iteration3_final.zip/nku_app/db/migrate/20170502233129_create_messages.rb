class CreateMessages < ActiveRecord::Migration[5.0]
  def change
    #drop_table :messages
    
    create_table :messages, primary_key: 'msg_id' do |t|
      t.references :from
      t.string :title
      t.string :content
      t.datetime :send_date
      t.references :user_id
    end
  end
end
