class CreateCourses < ActiveRecord::Migration[5.0]
  def change
    create_table :courses do |t|
      t.string :name
      t.string :text
      t.string :academic_label
      t.string :text
      t.string :course_id
      t.string :integer
      t.string :description
      t.string :text
      t.string :user
      t.string :references
      t.string :question
      t.string :references
      t.string :answer
      t.string :references

      t.timestamps
    end
  end
end
