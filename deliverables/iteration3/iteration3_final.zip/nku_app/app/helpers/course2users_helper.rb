module Course2usersHelper
    def add_course(course_id, user_id)
       Course2user.new(course_id, user_id)
    end
end
