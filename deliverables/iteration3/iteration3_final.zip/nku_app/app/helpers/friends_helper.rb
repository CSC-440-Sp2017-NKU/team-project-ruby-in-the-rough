module FriendsHelper
    def add_friend(user_id, user2_id)
       Friend.new(user_id, user2_id)
    end
end