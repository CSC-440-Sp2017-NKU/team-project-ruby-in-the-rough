module SessionsHelper
  def log_in(user)
    session[:user_id] = user.id
    #set time stamp
    user = User.find_by(id: user.id)
    user.update(time_stamp: Time.now)
  end
  
  def has_voted_A_up?(aid)
    avote = Answer_Vote.find_by(answer_id: aid, user_id: get_user?)
    if (avote.nil?)
      return false
    elsif (avote.value == 1)
      return true
    else
      return false
    end
  end
  
  def has_voted_A_down?(aid)
     avote = Answer_Vote.find_by(answer_id: aid, user_id: get_user?)
    if (avote.nil?)
      return false
    elsif (avote.value == -1)
      return true
    else
      return false
    end
  end
  
  def has_voted_up?(qid)
    qvote = Question_Vote.find_by(question_id: qid, user_id: get_user?)
    if (qvote.nil?)
      return false
    elsif (qvote.value == 1)
      return true
    else
      return false
    end
  end
  
  def has_voted_down?(qid)
    qvote = Question_Vote.find_by(question_id: qid, user_id: get_user?)
    if (qvote.nil?)
      return false
    elsif (qvote.value == -1)
      return true
    else
      return false
    end
  end
  
  # Returns the current logged-in user (if any).
  def current_user
    @current_user ||= User.find_by(id: session[:user_id])
  end

  def get_user?
    return session[:user_id]
  end
  
  def get_user_name?
    return User.find_by(id: session[:user_id]).name
  end

  # Returns true if the user is logged in, false otherwise.
  def logged_in?
    !current_user.nil?
  end
  
  def shares_course_id(user2)
    current_user.courses.each do |id_1|
      user2.courses.each do |id_2|
        if(id_1 == id_2)
          return true
        end
      end
    end
    return false
  end
  
  def can_view_crs(c_id)
    if (get_UAL? == 4)
      return true
    end
    c2u = Course2user.find_by(course_id: c_id, user_id: session[:user_id])
    
    if (!c2u.nil?) 
      return true
    else
      return false
    end
  end
  
  def set_course(course_id)
    session[:cur_course] = course_id
  end   
  
  def get_course?
    return session[:cur_course]
  end
  
  def set_question(question_id)
    session[:cur_question] = question_id
  end   
  
  def get_question?
    return session[:cur_question]
  end
  
  def owns_question(q_id)
    if (Question.find_by(id: q_id).user_id == get_user?)
      return true
    else
      return false
    end
  end
  
  def owns_answer(a_id)
    if (Answer.find_by(id: a_id).user_id == get_user?)
      return true
    else
      return false
    end
  end
  
  def set_viewed_user(u_id)
    session[:viewed_user] = u_id
  end
  
  def get_viewed_user?
    return session[:viewed_user]
  end
  
  def set_regis_cr_user(u_id)
    session[:regis_cr_user] = u_id
  end
  
  def get_regis_cr_user?
    return session[:regis_cr_user]
  end
  
  def get_UAL?
    if (!@current_user.nil?)
      return @current_user.accesslevel
    else
      return nil
    end
  end
  
  def log_out
    session.delete(:user_id)
    @current_user = nil
  end
  
  def set_to_user(uid)
    session[:to_uid] = uid
  end
  
  def get_to_user?
    return session[:to_uid]
  end
end