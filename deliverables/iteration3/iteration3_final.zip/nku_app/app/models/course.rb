class Course < ApplicationRecord
    has_many :questions
    has_many :users, :through => :course2users
    has_many :course2users
end
