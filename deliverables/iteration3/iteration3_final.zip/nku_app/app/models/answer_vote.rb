class Answer_Vote < ApplicationRecord
    belongs_to :user
    belongs_to :answer
end