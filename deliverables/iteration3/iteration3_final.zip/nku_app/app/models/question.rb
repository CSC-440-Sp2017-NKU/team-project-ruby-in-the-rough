class Question < ApplicationRecord
  belongs_to :user
  belongs_to :course
  has_many :answers
  has_many :question_votes
end
