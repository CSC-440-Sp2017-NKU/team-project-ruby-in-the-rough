class Course2user < ApplicationRecord
    belongs_to :course
    belongs_to :user
end
