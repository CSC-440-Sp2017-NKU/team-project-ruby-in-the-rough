class Answer_VotesController < ApplicationController
    before_action :set_answer_vote, only: [:destroy]
    
    def new
        @answer_vote = Answer_Vote.new
    end
    
    def edit
        
    end
    
    def create
        @answer_vote = Answer_Vote.new(answer_vote_params)
        @answer_vote.save
    end
    
    def update
        @answer_vote.update(answer_vote_params)
    end
    
    def destroy
        @answer_vote.destroy
    end
    
    private
        # Use callbacks to share common setup or constraints between actions.
        def set_answer_vote
            @answer_vote = Answer_Vote.find(params[:id])
        end
    
        # Never trust parameters from the scary internet, only allow the white list through.
        def answer_vote_params
          params.require(:answer_vote).permit(:answer_id, :user_id, :value)
        end
end
