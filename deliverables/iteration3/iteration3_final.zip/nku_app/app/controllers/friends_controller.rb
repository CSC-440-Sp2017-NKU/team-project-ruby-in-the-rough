class FriendsController < ApplicationController
    before_action :set_friend, only: [:destroy]
    
    def new
        @friend = Friend.new
    end
    
    def edit
    end
    
    def create
        @friend = Friend.new(friend_params)
        @friend.user_id = get_user?
        
        @friend2 = Friend.new()
        @friend2.user_id = @friend.user2_id
        @friend2.user2_id = @friend.user_id
        
        respond_to do |format|
            if @friend.save && @friend2.save
                format.html { redirect_to user_path(current_user), notice: 'Friend was successfully added.' }
                format.json { render :show, status: :created, location: @friend }
            else
                format.html { render :new }
                format.json { render json: @friend.errors, status: :unprocessable_entity }
            end
        end
    end
    
    def update
        respond_to do |format|
          if @friend.update(friend_params)
            format.html { redirect_to user_path(current_user), notice: 'Friend was successfully updated.' }
            format.json { render :show, status: :ok, location: @friend }
          else
            format.html { render :edit }
            format.json { render json: @friend.errors, status: :unprocessable_entity }
          end
        end
    end
    
    def destroy
        @friend = Friend.find_by(user_id: get_user?, user2_id: params[:user2_id])
        @friend2 = Friend.find_by(user_id: params[:user2_id], user2_id: get_user?)
        
        @friend.destroy
        @friend2.destroy
        respond_to do |format|
          format.html { redirect_to user_path(current_user), notice: 'Friend was successfully removed.' }
          format.json { head :no_content }
        end
    end
    
    private
        # Use callbacks to share common setup or constraints between actions.
        def set_friend
            
        end
    
        # Never trust parameters from the scary internet, only allow the white list through.
        def friend_params
          params.permit(:id, :user_id, :user2_id)
        end
end
