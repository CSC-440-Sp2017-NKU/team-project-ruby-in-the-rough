class ControlPanelsController < ApplicationController
    
end
