class Question_VotesController < ApplicationController
    before_action :set_question_vote, only: [:destroy]
    
    def new
        @question_vote = Question_Vote.new
    end
    
    def edit
        
    end
    
    def create
        @question_vote = Question_Vote.new(question_vote_params)
        @question_vote.save
    end
    
    def update
        @question_vote.update(question_vote_params)
    end
    
    def destroy
        @question_vote.destroy
    end
    
    private
        # Use callbacks to share common setup or constraints between actions.
        def set_question_vote
            @question_vote = Question_Vote.find(params[:id])
        end
    
        # Never trust parameters from the scary internet, only allow the white list through.
        def question_vote_params
          params.require(:question_vote).permit(:question_id, :user_id, :value)
        end
end
