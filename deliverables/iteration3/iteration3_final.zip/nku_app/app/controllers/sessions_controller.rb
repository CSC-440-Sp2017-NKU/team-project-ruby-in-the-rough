class SessionsController < ApplicationController
  def new
  end
  
  def create
    user = User.find_by(email: params[:session][:email].downcase)
    if user 
      log_in user
      if (user.accesslevel == 4)
        redirect_to moderator_path
      elsif (user.accesslevel == 3)
        redirect_to registrar_path
      else
        redirect_to user
      end
    else
      respond_to do |format|
        format.html { redirect_to root_url, notice: 'Incorrect E-Mail Address' }
        format.json { render :show, status: :ok, location: @question }
      end
      #redirect_to root_url
    end
  end
  
  def destroy
    log_out
    redirect_to root_url
  end
  
end
